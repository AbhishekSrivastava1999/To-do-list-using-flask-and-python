# Todo List Web Application

This is a simple web application built using Flask framework for managing a todo list. It allows users to create tasks, set due dates, update and delete tasks, and view tasks in a calendar format.

## Features

- User authentication: Users can register an account, log in, and log out.
- Create tasks: Users can add new tasks to their todo list.
- Set due dates: Users can specify start and end dates for their tasks.
- Update and delete tasks: Users can modify or remove existing tasks from their todo list.
- Calendar view: Users can view their tasks in a calendar format.

## Requirements

- Python 3.x
- Flask_SQLAlchemy
- Flask_Login
- Werkzeug
- Flask


## Installation and Setup

Use the following commands:

1. cd C:\Users\Owner\Desktop\Assignment
2. python3 -m venv env
3. env\scripts\activate
4. pip install Flask Flask-SQLAlchemy Werkzeug Flask-Login Flask-Session or you can use the requirements.txt to install the dependencies.
5. Open 2nd Terminal to start the database: db.create_all()
6. Open the Browser and navigate to localhost : http://127.0.0.1:5000/ 
